<?php
$con = mysqli_connect("localhost", "root", "", "db_calizaya") or die("Couldn't Connect");
?>
